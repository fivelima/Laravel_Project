@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>Education</h3>

              <div class="panel panel-default">
                <center>
          				Elementary: Pardo Elementary School<BR><BR>
          				High School: Pardo Night High School<BR><BR>
          				College: University Of Cebu (Main) <BR>
          				Course: Bachelor of Science in Information Technology<BR><BR>
          				Tesda: Computer Hardware Servicing NCII
              </center>
              </div>
            </div>
        </div>
    </div>
</div>
@stop