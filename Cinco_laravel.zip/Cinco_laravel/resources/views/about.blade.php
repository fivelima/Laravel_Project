@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h3>About</h3>

              <div class="panel panel-default">
                <center>
              
        				  My name is Hyrum S. Cinco<BR><BR>
        				  I leave in Pob. Pardo Cebu City<BR><BR>
        				  I'm the third son of our family<BR><BR>
        				  I born in Cebu<BR><BR>
        				  I am own my own for now<BR><BR>
        				  My last job is I was an travel consultant in a travel agency<BR><BR>
        				  I've been in luzon and mindanao in a quite time<BR><BR>
        				  I'm currently a 4th student<BR><BR>
        				  I study at University of Cebu Main<BR><BR>
        				  Hopefully I made it to graduate to this course<BR><BR>
        				  I love music<BR><BR>
        				  I can play a drumset<BR><BR>
        				  I love wandering around<BR><BR>
        				  I am slow in learning things<BR><BR>
        				  I like to travel in the world<BR><BR>
        				  I like to work in line of my course<BR><BR>
        				  I am simple<BR><BR>
        				  My dream is to become rich for now<BR><BR>
        				  My goal in this life is to obtain the higest blessings<BR><BR>
        				  I'm own my way for my future.
              
              </center>
              </div>
            </div>
        </div>
    </div>
</div>

@stop